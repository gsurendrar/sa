import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import {AngularFirestore} from 'angularfire2/firestore'
import { AlertController } from 'ionic-angular'
import { HomePage } from '../home/home';
import {AngularFireAuth} from'angularfire2/auth'


@Component({
  selector: 'login',
  templateUrl: 'login.html'
})
export class LoginPage {
  public userProfileCollection;
  public name;
  public employeeID;
  public contactNo;
  public password;
  constructor(public afa:AngularFireAuth, public navCtrl: NavController,private fireStore: AngularFirestore,public alertCtrl: AlertController) {
    
   // this.userProfileCollection = fireStore.doc<any>('userProfile/we45tfgy8ij');
    // this.userDoc.set({
    //   name: 'Jorge Vergara',
    //   email: 'j@javebratt.com',
    //   // Other info you want to add here
    // })
  }
submit()
{
  
  this.afa.auth.createUserAndRetrieveDataWithEmailAndPassword(this.employeeID+"@tcs.com",this.password);
  //this.afa.auth.createUserWithEmailAndPassword
  //alert(this.username)
  // alert(this.employeeID)
  // alert(this.contactNo);
  

  // this.userProfileCollection.set({
  //   name: this.name,
  //   employeeID: this.employeeID,
  //   contactNo:this.contactNo,
  //   password:this.password
  //   // Other info you want to add here
  // })

  const alert = this.alertCtrl.create({
    title: 'Registration Successfull!',
    subTitle:"Hey "+ this.name+" ,Please login with your new credentials",
    buttons:  [ {
      text: 'OK',
      handler: data => {
        this.navCtrl.push(HomePage)
      }
    }]
  });
  alert.present();
}


}
