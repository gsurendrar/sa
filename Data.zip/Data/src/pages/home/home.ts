import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { LoginPage } from '../login/login';
import {AngularFirestore} from 'angularfire2/firestore'
import {AngularFireAuth} from'angularfire2/auth'
import { bookingPage } from '../bookingPage/bookingPage';
import { adminPage } from '../adminPage/adminPage';


@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
   public userDoc;
   public employeeId;
   public password;

   constructor(public afa:AngularFireAuth,public navCtrl: NavController,private fireStore: AngularFirestore) {
  
  
    // this.userDoc = fireStore.doc<any>('userProfile/we45tfgy8ij');
    // console.log(this.userDoc);
    
  
  }
    signUp()
    {
    this.navCtrl.push(LoginPage)
    
    }
    async login()
    {

      try
      {
        
          const result=this.afa.auth.signInWithEmailAndPassword(this.employeeId+"@tcs.com",this.password);
        if(result)
        this.navCtrl.push(bookingPage)
    
    }
    catch(e){
  console.log(e)

    }
  }
  async Adminlogin(username: string, password: string) {
    try
    {
       
        const result= username= "admin" , password = "admin"
      if(result)
      console.log("result");
      this.navCtrl.push(adminPage)
  
  }
  catch(e){
console.log(e)
  }
}
}