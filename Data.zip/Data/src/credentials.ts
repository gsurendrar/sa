 export const config = {
    apiKey: "AIzaSyBoY-o7GP3fJj4yR9vLOdTuwN-E63MbWsM",
    authDomain: "reservation-system-4e2c1.firebaseapp.com",
    databaseURL: "https://reservation-system-4e2c1.firebaseio.com",
    projectId: "reservation-system-4e2c1",
    storageBucket: "reservation-system-4e2c1.appspot.com",
    messagingSenderId: "154136578685"
  };
