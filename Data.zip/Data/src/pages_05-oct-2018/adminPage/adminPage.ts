import { NavController, Alert } from 'ionic-angular';
import { AlertController } from 'ionic-angular'
import {AngularFirestore} from 'angularfire2/firestore'
import {AngularFireAuth} from'angularfire2/auth'
import {firestore} from'firebase'
import { FirebaseApp } from 'angularfire2';
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import { HttpClient } from '@angular/common/http';
import { HomePage } from '../home/home';
import { IonicPage, Nav } from 'ionic-angular';


export interface PageInterface {
  title: string;
  pageName: string;
  tabComponent?: any;
  index?: number;
  icon: string;
} 

@Component({
  selector: 'page-booking',
  templateUrl: 'adminPage.html'
})
export class adminPage{
   public userDoc;
   public employeeId;
   public password;
   public Source;
   public Destination;
   public myDate:String = new Date().toISOString();
   public result
   public busID;
   public busIDs =[];
   rootPage:any = HomePage;


   //    myDate: 
   constructor(public http:HttpClient, public firestore1:FirebaseApp,public afa:AngularFireAuth,public navCtrl: NavController,private fireStore: AngularFirestore,public alertCtrl: AlertController) {
  
  }
  
  DropdownVar = 0;

  bookaseat(){

    this.http.post('http://localhost:8081/booking',{"Source":this.Source,"Destination":this.Destination,"myDate":this.myDate.split("T")[0]})
   
    .subscribe(data => {
        
      this.result=data;
    })}

  Logout(){
    const  alert = this.alertCtrl.create({
      title: 'Logout Successfully',
      subTitle:"Please visit again",
      buttons:  [ {
        text: 'OK',
        handler: data => {
          this.navCtrl.push(HomePage)
        }
      }]
    });

  }
  
// confirm(busID){
//    const  alert = this.alertCtrl.create({
//         title: 'Your Seat is booked Successfully',
//         subTitle:"Please be on Time",
//         buttons:  [ {
//           text: 'OK',
//           handler: data => {
//             this.navCtrl.push(bookingPage)
//           }
//         }]
//       });

//     this.http.post('http://localhost:8081/updateSeats',{"BusID":busID})
   
//     .subscribe(data => {
//       this.result=data;
//     })

//   alert.present();
//   }
}