

var express = require('express');
var app = express();
var bodyParser = require('body-parser')
var mysql = require('mysql');

app.get('/', function (req, res) {
   res.send('Hello World');
})
app.use(bodyParser.json());
 app.listen(8081, function () {
 
   
   console.log("Example app listening at http://%s:%s")
})



app.use(function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  next();
});
app.post('/booking', function(req, res) {   
  console.log("hello");
 console.log(req.body);
var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "root123",
  database:"Bus_Reservation_system"
});

var source="'"+req.body.Source+"'";
var destination="'"+req.body.Destination+"'"
var date="'"+req.body.myDate+"'"

con.connect(function(err) {
var query='select * from Bus_avalibility where source='+source +'&& Destination='+destination+'&& Date_Of_Journey ='+date
console.log(query)
con.query(query, function (err, result, fields) {
    if (err) throw err;
console.log("result is");
    console.log(result);
res.send(result);
  });
  if (err) throw err;
  console.log("Connected!");
});
   
})

app.post('/updateSeats', function(req, res) {   
  
 console.log(req.body);

//var id="'"+req.body.Source+"'";

var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "root123",
  database:"Bus_Reservation_system"
});


con.connect(function(err) {
  if (err) throw err;
  var sql ='Select No_Of_Seats_Avaliable,Waiting_list from  Bus_avalibility WHERE Bus_ID =' +req.body.BusID;
  console.log(sql);
  //var sql = 'UPDATE Bus_avalibility SET No_Of_Seats_Avaliable = No_Of_Seats_Avaliable - 1 WHERE Bus_ID =' +req.body.BusID;

  con.query(sql, function (err, result) {
    console.log(result);
  var seats=result[0].No_Of_Seats_Avaliable;
  var waitinglist=result[0].Waiting_list;

  console.log("seats"+seats);
  console.log("waitinglist"+waitinglist);
  
if(seats>0)
var sql='UPDATE Bus_avalibility SET No_Of_Seats_Avaliable = No_Of_Seats_Avaliable - 1 WHERE Bus_ID =' +req.body.BusID;

if(seats==0 && waitinglist<10)
var sql='UPDATE Bus_avalibility SET  Waiting_list= Waiting_list+ 1 WHERE Bus_ID =' +req.body.BusID;

con.query(sql, function (err, result) {
      console.log(result);
    
    });
  });
});
});





